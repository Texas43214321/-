package com.amoled.chronograph

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Окно будильника/таймера: показывается поверх экрана блокировки. */
class RingActivity : Activity() {
    companion object { @Volatile var current: RingActivity? = null }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        current = this
        setShowWhenLocked(true); setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(this, null)

        val kind = intent.getStringExtra("kind") ?: "alarm"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK); setPadding(64, 64, 64, 64)
        }
        root.addView(TextView(this).apply {
            text = intent.getStringExtra("title"); setTextColor(Color.WHITE); textSize = 34f
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = intent.getStringExtra("sub"); setTextColor(Color.WHITE); textSize = 56f
            typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER
        })
        fun btn(label: String, white: Boolean, action: String) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 20f
            setTextColor(if (white) Color.BLACK else Color.WHITE)
            background = GradientDrawable().apply {
                cornerRadius = 200f
                setColor(if (white) Color.WHITE else Color.rgb(40, 40, 40))
            }
            setOnClickListener {
                startService(Intent(this@RingActivity, RingService::class.java).setAction(action))
                finish()
            }
            layoutParams = LinearLayout.LayoutParams(-1, 170).apply { topMargin = 28 }
        }
        if (kind == "alarm") root.addView(btn("Ещё 5 минут", false, RingService.ACTION_SNOOZE))
        root.addView(btn("Стоп", true, RingService.ACTION_STOP))
        setContentView(root)
    }

    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }
    @Deprecated("") override fun onBackPressed() {}   // закрыть можно только кнопками
}
