package com.amoled.chronograph

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Расписание хранится в SharedPreferences: переживает выгрузку приложения и перезагрузку. */
object Sched {
    private const val PREFS = "clock"
    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun items(c: Context): JSONArray = JSONArray(prefs(c).getString("items", "[]"))
    fun logError(c: Context, m: String) {
        val old = prefs(c).getString("err", "") ?: ""
        prefs(c).edit().putString("err", (old + "\n" + m).takeLast(700)).apply()
    }
    fun takeError(c: Context): String {
        val e = prefs(c).getString("err", "") ?: ""
        if (e.isNotEmpty()) prefs(c).edit().putString("err", "").apply()
        return e.trim()
    }
    fun vol(c: Context) = prefs(c).getInt("vol", 3)
    fun vib(c: Context) = prefs(c).getInt("vib", 2)

    private fun putItems(c: Context, a: JSONArray) { prefs(c).edit().putString("items", a.toString()).apply() }

    private fun pi(c: Context, id: String, create: Boolean): PendingIntent? {
        val i = Intent(c, AlarmReceiver::class.java).setAction("clock.fire").putExtra("id", id)
        val flags = PendingIntent.FLAG_IMMUTABLE or (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE)
        return PendingIntent.getBroadcast(c, id.hashCode(), i, flags)
    }

    private fun cancelOne(c: Context, id: String) {
        val p = pi(c, id, false) ?: return
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(p)
        p.cancel()
    }

    private fun scheduleOne(c: Context, o: JSONObject) {
        val at = o.getLong("at")
        if (at <= System.currentTimeMillis()) return
        val show = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // setAlarmClock: точный, работает в Doze и при выгруженном приложении
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), pi(c, o.getString("id"), true)!!)
    }

    /** Полная замена расписания тем, что прислал HTML. */
    @Synchronized fun apply(c: Context, json: String) {
        val root = JSONObject(json)
        val old = items(c)
        for (i in 0 until old.length()) cancelOne(c, old.getJSONObject(i).getString("id"))
        val now = root.getJSONArray("items")
        val keep = JSONArray()
        for (i in 0 until now.length()) {
            val o = now.getJSONObject(i)
            if (o.getLong("at") > System.currentTimeMillis()) { keep.put(o); scheduleOne(c, o) }
        }
        putItems(c, keep)
        prefs(c).edit().putInt("vol", root.optInt("vol", 3)).putInt("vib", root.optInt("vib", 2)).apply()
    }

    fun nextOccurrence(time: String, days: JSONArray?): Long {
        val (h, m) = time.split(":").map { it.toInt() }
        val now = System.currentTimeMillis()
        for (i in 0..8) {
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, i)
            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, m); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
            if (cal.timeInMillis <= now) continue
            val dow = cal.get(Calendar.DAY_OF_WEEK) - 1           // 0 = воскресенье, как в JS getDay()
            if (days != null && days.length() > 0 && !(0 until days.length()).any { days.getInt(it) == dow }) continue
            return cal.timeInMillis
        }
        return 0
    }

    private fun addEvent(c: Context, e: JSONObject) {
        val a = JSONArray(prefs(c).getString("events", "[]")); a.put(e)
        prefs(c).edit().putString("events", a.toString()).apply()
    }

    @Synchronized fun takeEvents(c: Context): String {
        val s = prefs(c).getString("events", "[]") ?: "[]"
        prefs(c).edit().putString("events", "[]").apply()
        return s
    }

    /** Сработал будильник/таймер: пишем событие для HTML, повторяющийся будильник ставим на следующий раз. */
    @Synchronized fun onFired(c: Context, id: String): JSONObject? {
        val all = items(c)
        var hit: JSONObject? = null
        val rest = JSONArray()
        for (i in 0 until all.length()) {
            val o = all.getJSONObject(i)
            if (o.getString("id") == id) hit = o else rest.put(o)
        }
        val h = hit ?: return null
        addEvent(c, JSONObject().put("type", "fired").put("id", id).put("at", h.getLong("at")))
        val days = h.optJSONArray("days")
        if (h.optString("kind") == "alarm" && id != "snooze" && days != null && days.length() > 0 && h.has("time")) {
            val next = nextOccurrence(h.getString("time"), days)
            if (next > 0) { val n = JSONObject(h.toString()).put("at", next); rest.put(n); scheduleOne(c, n) }
        }
        putItems(c, rest)
        return h
    }

    @Synchronized fun snooze(c: Context, label: String) {
        val at = System.currentTimeMillis() + 5 * 60000L
        val o = JSONObject().put("id", "snooze").put("kind", "alarm").put("at", at).put("title", label).put("sub", "")
        val all = items(c); val rest = JSONArray()
        for (i in 0 until all.length()) { val x = all.getJSONObject(i); if (x.getString("id") != "snooze") rest.put(x) }
        cancelOne(c, "snooze")
        rest.put(o); putItems(c, rest); scheduleOne(c, o)
        addEvent(c, JSONObject().put("type", "snooze").put("at", at).put("label", label))
    }

    /** После перезагрузки телефона. */
    @Synchronized fun rescheduleAll(c: Context) {
        val all = items(c); val keep = JSONArray(); val now = System.currentTimeMillis()
        for (i in 0 until all.length()) {
            var o = all.getJSONObject(i)
            if (o.getLong("at") <= now) {
                val days = o.optJSONArray("days")
                if (o.optString("kind") == "alarm" && days != null && days.length() > 0 && o.has("time")) {
                    val next = nextOccurrence(o.getString("time"), days)
                    if (next > 0) o = JSONObject(o.toString()).put("at", next) else continue
                } else continue
            }
            keep.put(o); scheduleOne(c, o)
        }
        putItems(c, keep)
    }
}
