package com.amoled.chronograph

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Base64
import android.webkit.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooser: ValueCallback<Array<Uri>>? = null

    inner class Bridge {
        @JavascriptInterface fun sync(json: String) { Sched.apply(applicationContext, json) }
        @JavascriptInterface fun takeEvents(): String = Sched.takeEvents(applicationContext)
        @JavascriptInterface fun setSound(kind: String, b64: String) {
            if (kind != "alarm" && kind != "timer") return
            val f = File(filesDir, "snd_$kind")
            if (b64.isEmpty()) { f.delete(); return }
            try { f.writeBytes(Base64.decode(b64, Base64.DEFAULT)) } catch (_: Exception) {}
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0; window.navigationBarColor = 0
        web = WebView(this)
        web.setBackgroundColor(0xFF000000.toInt())
        web.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
        }
        web.addJavascriptInterface(Bridge(), "AndroidClock")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                chooser?.onReceiveValue(null); chooser = cb
                return try { startActivityForResult(p.createIntent(), 11); true } catch (e: Exception) { chooser = null; false }
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        askPermissions()
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 11) { chooser?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); chooser = null }
        else super.onActivityResult(rc, res, d)
    }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5); return
        }
        val p = getSharedPreferences("perm", MODE_PRIVATE)
        if (Build.VERSION.SDK_INT >= 34 && !p.getBoolean("fsi", false) &&
            !getSystemService(NotificationManager::class.java).canUseFullScreenIntent()) {
            p.edit().putBoolean("fsi", true).apply()
            startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))); return
        }
        if (!p.getBoolean("ovl", false) && !Settings.canDrawOverlays(this)) {
            p.edit().putBoolean("ovl", true).apply()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, perms, r); askPermissions()
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
