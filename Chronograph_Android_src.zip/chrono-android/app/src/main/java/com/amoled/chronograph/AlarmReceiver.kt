package com.amoled.chronograph

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val item = Sched.onFired(c, id) ?: return
        val s = Intent(c, RingService::class.java).setAction(RingService.ACTION_START)
            .putExtra("title", item.optString("title", "Будильник"))
            .putExtra("sub", item.optString("sub", ""))
            .putExtra("kind", item.optString("kind", "alarm"))
        c.startForegroundService(s)
    }
}
