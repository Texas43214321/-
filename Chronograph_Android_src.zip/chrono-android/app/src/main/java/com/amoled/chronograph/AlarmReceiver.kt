package com.amoled.chronograph

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val item = Sched.onFired(c, id) ?: return
        val title = item.optString("title", "Будильник")
        val sub = item.optString("sub", "")
        val kind = item.optString("kind", "alarm")
        try {
            c.startForegroundService(Intent(c, RingService::class.java).setAction(RingService.ACTION_START)
                .putExtra("title", title).putExtra("sub", sub).putExtra("kind", kind))
        } catch (e: Exception) {
            Sched.logError(c, "service: " + e.javaClass.simpleName + ": " + e.message)
            try { RingService.fallbackNotify(c, title, sub, kind) } catch (e2: Exception) {
                Sched.logError(c, "notify: " + e2.javaClass.simpleName + ": " + e2.message)
            }
        }
    }
}
