package com.amoled.chronograph

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.*
import java.io.File

class RingService : Service() {
    companion object {
        const val ACTION_START = "clock.start"
        const val ACTION_STOP = "clock.stop"
        const val ACTION_SNOOZE = "clock.snooze"
        private const val CH = "ring"
        private const val NID = 77
        private val VOL = floatArrayOf(0f, 0.3f, 0.6f, 1f)
    }

    private var player: MediaPlayer? = null
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var title = "Будильник"
    private var sub = ""
    private var kind = "alarm"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_STOP -> { finishRing(); return START_NOT_STICKY }
            ACTION_SNOOZE -> { Sched.snooze(this, title); finishRing(); return START_NOT_STICKY }
        }
        title = i?.getStringExtra("title") ?: title
        sub = i?.getStringExtra("sub") ?: sub
        kind = i?.getStringExtra("kind") ?: kind
        startRing()
        return START_NOT_STICKY
    }

    private fun startRing() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Будильник и таймер", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        val full = PendingIntent.getActivity(this, 2, ringIntent(), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val nb = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(if (kind == "timer") "Время вышло" else sub)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true).setFullScreenIntent(full, true).setContentIntent(full)
            .addAction(Notification.Action.Builder(0, "Стоп", act(ACTION_STOP, 3)).build())
        if (kind == "alarm") nb.addAction(Notification.Action.Builder(0, "Ещё 5 минут", act(ACTION_SNOOZE, 4)).build())
        val n = nb.build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NID, n)

        wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chrono:ring").apply { acquire(11 * 60 * 1000L) }

        try { startActivity(ringIntent()) } catch (e: Exception) { /* останется полноэкранное уведомление */ }
        playSound(); vibrate()
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ finishRing() }, if (kind == "timer") 5 * 60000L else 10 * 60000L)
    }

    private fun ringIntent() = Intent(this, RingActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        .putExtra("title", title).putExtra("sub", if (kind == "timer") "Время вышло" else sub).putExtra("kind", kind)

    private fun act(a: String, code: Int) =
        PendingIntent.getService(this, code, Intent(this, RingService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)

    private fun playSound() {
        val v = VOL[Sched.vol(this).coerceIn(0, 3)]
        if (v <= 0f) return
        try {
            player?.release()
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            val f = File(filesDir, "snd_$kind")
            if (f.exists() && f.length() > 0) mp.setDataSource(f.absolutePath)
            else mp.setDataSource(this, RingtoneManager.getDefaultUri(
                if (kind == "timer") RingtoneManager.TYPE_NOTIFICATION else RingtoneManager.TYPE_ALARM))
            mp.isLooping = true; mp.setVolume(v, v)
            mp.prepare(); mp.start(); player = mp
        } catch (e: Exception) {
            try {   // файл битый — звоним стандартным
                val mp = MediaPlayer.create(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
                mp.isLooping = true; mp.setVolume(v, v); mp.start(); player = mp
            } catch (_: Exception) {}
        }
    }

    private fun vibrate() {
        if (Sched.vib(this) <= 0) return
        val pattern = longArrayOf(0, 300, 150, 300, 150, 300, 900)
        val vb = if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator
                 else @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        vb.vibrate(VibrationEffect.createWaveform(pattern, 0))
    }

    private fun finishRing() {
        h.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) {}
        player?.release(); player = null
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
        if (wl?.isHeld == true) wl?.release()
        RingActivity.current?.finish()
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
    }

    override fun onDestroy() { finishRing2(); super.onDestroy() }
    private fun finishRing2() { try { player?.release() } catch (_: Exception) {}; player = null }
}
