package com.amoled.chronograph

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.*
import java.io.File

class RingService : Service() {
    companion object {
        const val ACTION_START = "clock.start"
        const val ACTION_STOP = "clock.stop"
        const val ACTION_SNOOZE = "clock.snooze"
        private const val CH = "ring2"
        private const val CH_FB = "ring_fb"
        private const val NID = 77
        private val VOL = floatArrayOf(0f, 0.3f, 0.6f, 1f)

        fun ringIntent(c: Context, title: String, sub: String, kind: String) = Intent(c, RingActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
            .putExtra("title", title).putExtra("sub", if (kind == "timer") "Время вышло" else sub).putExtra("kind", kind)

        /** Запасной вариант: обычное уведомление со звуком будильника и полноэкранным окном. */
        fun fallbackNotify(c: Context, title: String, sub: String, kind: String) {
            val nm = c.getSystemService(NotificationManager::class.java)
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            nm.createNotificationChannel(NotificationChannel(CH_FB, "Будильник (запасной)", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(uri, AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                enableVibration(true); vibrationPattern = longArrayOf(0, 500, 300, 500, 300, 500)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            })
            val full = PendingIntent.getActivity(c, 2, ringIntent(c, title, sub, kind), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(c, CH_FB).setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title).setContentText(if (kind == "timer") "Время вышло" else sub)
                .setCategory(Notification.CATEGORY_ALARM).setFullScreenIntent(full, true).setContentIntent(full)
                .setAutoCancel(true).build()
            nm.notify(78, n)
            try { c.startActivity(ringIntent(c, title, sub, kind)) } catch (_: Exception) {}
        }
    }

    private var player: MediaPlayer? = null
    private var tone: ToneGenerator? = null
    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private var title = "Будильник"
    private var sub = ""
    private var kind = "alarm"

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        try {
            when (i?.action) {
                ACTION_STOP -> { finishRing(); return START_NOT_STICKY }
                ACTION_SNOOZE -> { Sched.snooze(this, title); finishRing(); return START_NOT_STICKY }
            }
            title = i?.getStringExtra("title") ?: title
            sub = i?.getStringExtra("sub") ?: sub
            kind = i?.getStringExtra("kind") ?: kind
            startRing()
        } catch (e: Exception) {
            Sched.logError(this, "onStart: " + e.javaClass.simpleName + ": " + e.message)
        }
        return START_NOT_STICKY
    }

    private fun startRing() {
        var fg = false
        try { goForeground(); fg = true } catch (e: Exception) {
            Sched.logError(this, "foreground: " + e.javaClass.simpleName + ": " + e.message)
        }
        try {
            wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "chrono:ring").apply { acquire(11 * 60 * 1000L) }
        } catch (_: Exception) {}
        try { startActivity(ringIntent(this, title, sub, kind)) } catch (e: Exception) {
            Sched.logError(this, "window: " + e.javaClass.simpleName)
        }
        if (!fg) { try { fallbackNotify(this, title, sub, kind) } catch (_: Exception) {} }
        playSound(); vibrate()
        h.removeCallbacksAndMessages(null)
        h.postDelayed({ finishRing() }, if (kind == "timer") 5 * 60000L else 10 * 60000L)
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Будильник и таймер", NotificationManager.IMPORTANCE_HIGH).apply {
            setSound(null, null); enableVibration(false); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        })
        val full = PendingIntent.getActivity(this, 2, ringIntent(this, title, sub, kind), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val nb = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title).setContentText(if (kind == "timer") "Время вышло" else sub)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true).setFullScreenIntent(full, true).setContentIntent(full)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "Стоп", act(ACTION_STOP, 3)).build())
        if (kind == "alarm") nb.addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Ещё 5 минут", act(ACTION_SNOOZE, 4)).build())
        val n = nb.build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(NID, n)
    }

    private fun act(a: String, code: Int) =
        PendingIntent.getService(this, code, Intent(this, RingService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE)

    private fun playSound() {
        val v = VOL[Sched.vol(this).coerceIn(0, 3)]
        if (v <= 0f) return
        try {   // если громкость будильника стоит на нуле — поднимаем, иначе звонок не слышно
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) == 0)
                am.setStreamVolume(AudioManager.STREAM_ALARM, (am.getStreamMaxVolume(AudioManager.STREAM_ALARM) * 0.6).toInt().coerceAtLeast(1), 0)
        } catch (_: Exception) {}

        val sources = ArrayList<Any>()
        val f = File(filesDir, "snd_$kind")
        if (f.exists() && f.length() > 0) sources.add(f.absolutePath)
        val types = if (kind == "timer")
            intArrayOf(RingtoneManager.TYPE_NOTIFICATION, RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_RINGTONE)
        else intArrayOf(RingtoneManager.TYPE_ALARM, RingtoneManager.TYPE_RINGTONE, RingtoneManager.TYPE_NOTIFICATION)
        for (t in types) { try { RingtoneManager.getActualDefaultRingtoneUri(this, t)?.let { sources.add(it) } } catch (_: Exception) {}
                           try { RingtoneManager.getDefaultUri(t)?.let { sources.add(it) } } catch (_: Exception) {} }

        for (src in sources) {
            try {
                val mp = MediaPlayer()
                mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                if (src is String) mp.setDataSource(src) else mp.setDataSource(this, src as Uri)
                mp.isLooping = true; mp.setVolume(v, v)
                mp.prepare(); mp.start(); player = mp
                return
            } catch (_: Exception) {}
        }
        // ничего не подошло — пищим встроенным генератором тона
        Sched.logError(this, "sound: system ringtones unavailable, using tone")
        try {
            val tg = ToneGenerator(AudioManager.STREAM_ALARM, (100 * v).toInt().coerceAtLeast(30)); tone = tg
            val r = object : Runnable { override fun run() { tg.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 800); h.postDelayed(this, 1500) } }
            h.post(r)
        } catch (e: Exception) { Sched.logError(this, "tone: " + e.javaClass.simpleName) }
    }

    private fun vibrate() {
        if (Sched.vib(this) <= 0) return
        try {
            val pattern = longArrayOf(0, 300, 150, 300, 150, 300, 900)
            val vb = if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator
                     else @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vb.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } catch (_: Exception) {}
    }

    private fun finishRing() {
        h.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        try { tone?.release() } catch (_: Exception) {}
        tone = null
        try { (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel() } catch (_: Exception) {}
        try { if (wl?.isHeld == true) wl?.release() } catch (_: Exception) {}
        try { getSystemService(NotificationManager::class.java).cancel(78) } catch (_: Exception) {}
        RingActivity.current?.finish()
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onDestroy() { try { player?.release() } catch (_: Exception) {}; player = null; super.onDestroy() }
}
