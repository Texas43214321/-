plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.amoled.chronograph"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.amoled.chronograph"   // поставь свой applicationId от версии 3.1.0, чтобы обновиться поверх
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "3.2.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
